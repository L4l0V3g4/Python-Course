def sumar(a, b):
    """
    Suma dos valores.
    """
    return a+b


def restar(a, b):
    """
    Resta dos valores.
    """
    return a-b


def multiplicar(a, b):
    """
    Multiplica dos valores.
    """
    return a*b


def dividir(a, b):
    """
    Divide dos valores.
    """
    return a/b
